package me.pgb.a2021_04_26_room.db;

public enum DatabaseOperations {

    INSERT,
    DELETE,
    UPDATE
}
